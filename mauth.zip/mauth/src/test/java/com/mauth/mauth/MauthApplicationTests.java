package com.mauth.mauth;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MauthApplicationTests {

	@Test
	void contextLoads() {
	}

}
