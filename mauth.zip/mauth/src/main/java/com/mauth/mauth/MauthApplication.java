package com.mauth.mauth;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MauthApplication {

	public static void main(String[] args) {
		SpringApplication.run(MauthApplication.class, args);
	}

}
